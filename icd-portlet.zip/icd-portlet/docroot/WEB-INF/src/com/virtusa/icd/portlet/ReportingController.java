package com.virtusa.icd.portlet;


import java.util.SortedSet;

import org.springframework.stereotype.Controller;

import com.virtusa.icd.service.ReportingService;

@Controller
public class ReportingController {
	
	private ReportingService service;

	public ReportingService getService() {
		return service;
	}


	public void setService(ReportingService service) {
		this.service = service;
	}


	public SortedSet getEntityTypes() {
		return this.service.getEntityTypes();
	}


	public String show() {
		return "reporting";
	}
}