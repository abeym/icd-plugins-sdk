package com.virtusa.icd.service;

import java.util.SortedSet;
import java.util.TreeSet;

public interface PortalManagementService {

	public SortedSet getEntityTypes();

}
