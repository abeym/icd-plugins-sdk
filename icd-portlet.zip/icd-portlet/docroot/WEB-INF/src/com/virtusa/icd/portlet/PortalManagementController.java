package com.virtusa.icd.portlet;


import java.util.SortedSet;

import org.springframework.stereotype.Controller;

import com.virtusa.icd.service.PortalManagementService;

@Controller
public class PortalManagementController {
	
	private PortalManagementService service;

	public PortalManagementService getService() {
		return service;
	}


	public void setService(PortalManagementService service) {
		this.service = service;
	}

	public SortedSet getEntityTypes() {
		return this.service.getEntityTypes();
	}


	public String show() {
		return "portalmanagement";
	}
}