package com.virtusa.icd.portlet;

import java.net.BindException;
import java.util.Date;
import java.util.SortedSet;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.portlet.ModelAndView;
import org.springframework.web.portlet.bind.annotation.ActionMapping;
import org.springframework.web.portlet.mvc.AbstractController;

import com.liferay.counter.service.CounterLocalServiceUtil;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.portal.model.ClassName;
import com.liferay.portal.model.Contact;
import com.liferay.portal.model.Group;
import com.liferay.portal.model.LayoutSet;
import com.liferay.portal.model.Organization;
import com.liferay.portal.model.ResourcePermission;
import com.liferay.portal.model.Role;
import com.liferay.portal.model.User;
import com.liferay.portal.service.ClassNameLocalServiceUtil;
import com.liferay.portal.service.ContactLocalServiceUtil;
import com.liferay.portal.service.GroupLocalServiceUtil;
import com.liferay.portal.service.LayoutSetLocalServiceUtil;
import com.liferay.portal.service.ResourcePermissionLocalServiceUtil;
import com.liferay.portal.service.RoleLocalServiceUtil;
import com.liferay.portal.service.ServiceContext;
import com.liferay.portal.service.UserGroupRoleLocalServiceUtil;
import com.liferay.portal.service.UserLocalServiceUtil;
import com.liferay.portal.theme.ThemeDisplay;
import com.liferay.portal.util.PortalUtil;
import com.liferay.portlet.asset.model.AssetEntry;
import com.liferay.portlet.asset.service.AssetEntryLocalServiceUtil;
import com.virtusa.icd.service.EnrollmentService;

//import org.springframework.web.servlet.mvc.SimpleFormController;

@Controller
public class EnrollmentController extends AbstractController {

	private EnrollmentService service;

	public EnrollmentService getService() {
		return service;
	}

	public void setService(EnrollmentService service) {
		this.service = service;
	}

	public SortedSet getEntityTypes() {
		return this.service.getEntityTypes();
	}

	@RequestMapping(value = "VIEW")
	public String showEnrollment() {
		return "enrollment";
	}

	public ModelAndView handleRenderRequest(RenderRequest request,
			RenderResponse response) throws Exception {
		ModelAndView mv = new ModelAndView("enrollment");
		return mv;
	}

	@RequestMapping(value = "VIEW")
	@ActionMapping(params = "action=upload")
	public void handleActionRequest(ActionRequest request,
			ActionResponse response) throws SystemException {
		String selectedEntityType = request.getParameter("selectedEntityType");
		String organizationNPINum = request.getParameter("organizationNPINum");
		String organizationName = request.getParameter("organizationName");
		service.addEnrollment(selectedEntityType, organizationNPINum,
				organizationName);
		// return "enrollment";
	}

	public void onSubmitAction(ActionRequest request, ActionResponse response,
			Object command, BindException errors) throws Exception {

		// cast the bean
		FileUploadBean bean = (FileUploadBean) command;

		// let's see if there's content there
		MultipartFile file = bean.getFile();
		if (file == null) {
			// hmm, that's strange, the user did not upload anything
		}

		// do something with the file here
	}

	private User insertOrgAdmin(ActionRequest actionRequest,
			Organization organization, ServiceContext serviceContext,
			long gpIdForUser) throws SystemException,
			com.liferay.portal.kernel.exception.PortalException {
		ThemeDisplay themeDisplay = (ThemeDisplay) actionRequest
				.getAttribute(WebKeys.THEME_DISPLAY);
		long companyId = themeDisplay.getCompanyId();
		long groupId = gpIdForUser;
		String password1 = "orgadmin";// organization.getName().toLowerCase();
		String domainName = null;
		long facebookId = 0;
		String openId = null;
		// String firstName=organization.getName();
		String lastName = organization.getName();
		int prefixId = 123;
		int suffixId = 234;
		String jobTitle = "Organization Administrator";
		domainName = organization.getName();
		domainName = domainName.trim();
		if (domainName.contains(" ")) {
			domainName = domainName.replaceAll("\\s+", "-");
		}
		// String emailAddress="administrator@"+domainName+".com";
		String emailAddress = "administrator@panchayatportal.gov.in";
		Role role = RoleLocalServiceUtil.getRole(companyId,
				"Organization Administrator");
		User user = null;
		if (role != null) {
			long idContact = CounterLocalServiceUtil.increment(Contact.class
					.getName());
			// String greeting="Welcome "+role.getName();
			String greeting = "Welcome Admin";
			long id = CounterLocalServiceUtil.increment(User.class.getName());
			user = UserLocalServiceUtil.createUser(id);
			user.setCompanyId(companyId);
			user.setPassword(password1);
			// String screenName=organization.getName().toLowerCase()+id;
			String screenName = "admin" + id;
			user.setScreenName(screenName);
			user.setEmailAddress(emailAddress);
			user.setFacebookId(facebookId);
			user.setOpenId(openId);
			user.setGreeting(greeting);
			// user.setFirstName(firstName);
			user.setFirstName("Site Admin");
			// user.setLastName(lastName);
			user.setJobTitle(jobTitle);
			user.setCreateDate(new Date());
			user.setContactId(idContact);
			user.setPasswordReset(true);
			user.setPasswordEncrypted(false);
			user.setPasswordModifiedDate(new Date());
			user.setCreateDate(new Date());
			user.setModifiedDate(new Date());
			user.setLanguageId(themeDisplay.getLanguageId());
			user.setTimeZoneId(themeDisplay.getTimeZone().getDisplayName());
			UserLocalServiceUtil.addUser(user);

			// Associate a role with user
			long userid[] = { user.getUserId() };

			// UserLocalServiceUtil.addRoleUsers(role.getRoleId(), userid);
			Role rolePu = RoleLocalServiceUtil.getRole(companyId, "Power User");
			// UserLocalServiceUtil.addRoleUsers(rolePu.getRoleId(), userid);
			long roleids[] = { role.getRoleId(), rolePu.getRoleId() };
			UserGroupRoleLocalServiceUtil.addUserGroupRoles(user.getUserId(),
					groupId, roleids);

			ClassName clsNameUser = ClassNameLocalServiceUtil
					.getClassName("com.liferay.portal.model.User");
			long classNameId = clsNameUser.getClassNameId();

			// Insert Group for a user
			long gpId = CounterLocalServiceUtil
					.increment(Group.class.getName());
			Group userGrp = GroupLocalServiceUtil.createGroup(gpId);
			userGrp.setClassNameId(classNameId);
			userGrp.setClassPK(userid[0]);
			userGrp.setCompanyId(companyId);
			userGrp.setName("group" + String.valueOf(userid[0]));
			userGrp.setFriendlyURL("/group" + gpId);
			userGrp.setCreatorUserId(PortalUtil.getUserId(actionRequest));
			userGrp.setActive(true);
			GroupLocalServiceUtil.addGroup(userGrp);

			// Insert Contact for a user
			// long idContact =
			// CounterLocalServiceUtil.increment(Contact.class.getName());
			Contact contact = ContactLocalServiceUtil.createContact(idContact);
			contact.setCompanyId(companyId);
			contact.setCreateDate(new Date());
			contact.setUserName(screenName);
			contact.setUserId(user.getUserId());
			contact.setModifiedDate(new Date());
			contact.setFirstName("contact-" + contact.getContactId());
			contact.setLastName("contact-" + contact.getContactId());
			contact.setMiddleName("contact-" + contact.getContactId());
			contact.setPrefixId(prefixId);
			contact.setSuffixId(suffixId);
			contact.setJobTitle(jobTitle + contact.getContactId());
			contact.setBirthday(new Date());
			ContactLocalServiceUtil.addContact(contact);

			// Create AssetEntry
			long assetEntryId = CounterLocalServiceUtil
					.increment(AssetEntry.class.getName());
			AssetEntry ae = AssetEntryLocalServiceUtil
					.createAssetEntry(assetEntryId);
			ae.setCompanyId(companyId);
			ae.setClassPK(user.getUserId());
			ae.setGroupId(userGrp.getGroupId());
			ae.setClassNameId(classNameId);
			AssetEntryLocalServiceUtil.addAssetEntry(ae);

			// Insert ResourcePermission for a User
			long resPermId = CounterLocalServiceUtil
					.increment(ResourcePermission.class.getName());
			ResourcePermission rpEntry = ResourcePermissionLocalServiceUtil
					.createResourcePermission(resPermId);
			rpEntry.setCompanyId(organization.getCompanyId());
			rpEntry.setName("com.liferay.portal.model.User");
			rpEntry.setRoleId(role.getRoleId());
			rpEntry.setScope(4);
			rpEntry.setActionIds(31);
			// rpEntry.setPrimaryKey(userid[0]);
			ResourcePermissionLocalServiceUtil.addResourcePermission(rpEntry);

			// Insert Layoutset for public and private
			long layoutSetIdPub = CounterLocalServiceUtil
					.increment(LayoutSet.class.getName());
			LayoutSet layoutSetPub = LayoutSetLocalServiceUtil
					.createLayoutSet(layoutSetIdPub);
			layoutSetPub.setCompanyId(companyId);
			layoutSetPub.setPrivateLayout(false);
			layoutSetPub.setGroupId(userGrp.getGroupId());
			layoutSetPub.setThemeId("classic");
			try {
				LayoutSetLocalServiceUtil.addLayoutSet(layoutSetPub);
			} catch (SystemException se) {

			}

			long layoutSetIdPriv = CounterLocalServiceUtil
					.increment(LayoutSet.class.getName());
			LayoutSet layoutSetPriv = LayoutSetLocalServiceUtil
					.createLayoutSet(layoutSetIdPriv);
			layoutSetPriv.setCompanyId(companyId);
			layoutSetPriv.setPrivateLayout(true);
			layoutSetPriv.setThemeId("classic");
			layoutSetPriv.setGroupId(userGrp.getGroupId());
			try {
				LayoutSetLocalServiceUtil.addLayoutSet(layoutSetPriv);
			} catch (SystemException se) {
			}
		} else {
			return null;
		}

		return user;

	}
}
