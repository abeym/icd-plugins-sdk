package com.virtusa.icd.portlet;


import java.util.SortedSet;

import org.springframework.stereotype.Controller;

import com.virtusa.icd.service.MradminService;

@Controller
public class MradminController {
	
	private MradminService service;

	public MradminService getService() {
		return service;
	}


	public void setService(MradminService service) {
		this.service = service;
	}


	public SortedSet getEntityTypes() {
		return this.service.getEntityTypes();
	}


	public String showMradmin() {
		return "mradmin";
	}
}